import math
from point import Point


class Line:
    """
        A class which will calculate a line given 2 arguments, start point and end point.

        Attributes:
            start_point: tuple
                The start point is a tuple holding 2 points on a grid.
            end_point: tuple
                The end point is a tuple holing 2 points on a grid.
        @Properties:
            start_point:
                :returns the starting point of a line
            end_point:
                :returns the ending point of a line

        Methods:
            None
    """

    def __init__(self, start_point, end_point):
        """
            Constructs all necessary attributes of the line class
            :param start_point:
                Two points on a grid collected from the point class
            :param end_point:
                Two points on a grid
        """
        self.__start_point = start_point
        self.__end_point = end_point

    @property
    def start_point(self):
        """
        :returns starting point
        """
        return self.__start_point

    @property
    def end_point(self):
        """
        :returns ending point
        """

        return self.__end_point

    @property
    def length(self):
        """
        :returns the length of a line between 2 points
        """
        return math.sqrt(
            (self.end_point.x - self.start_point.x) ** 2 + (self.end_point.y - self.start_point.y) ** 2)

    @end_point.setter
    def end_point(self, new_value):
        """
        Sets a new end point if one is given
        """
        self.__end_point = new_value

    def __eq__(self, other):
        return self.length == other.length

    def __gt__(self, other):
        return self.length > other.length

    def __lt__(self, other):
        return self.length < other.length

def choices():
    print('1. Create two points')
    print('2. Edit point 2')
    print('3. display the 2 points')
    print('4. Print the length between the two points')
    print('0. exit')


if __name__ == "__main__":
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                """
                    Takes 5 inputs from the user asking them for the name of the line, and 4 points, x1, x2, y1, y2 and
                    Then creates the circle.
                """
                user_line_name = input('Enter a name for the line: ')
                user_point_x_1 = int(input('Enter point x1: '))
                user_point_x_2 = int(input('Enter point x2: '))
                user_point_y_1 = int(input('Enter point y1: '))
                user_point_y_2 = int(input('Enter point y2: '))
                p1 = Point(user_point_x_1, user_point_y_1)
                p2 = Point(user_point_x_2, user_point_y_2)
                user_line_name = Line(p1, p2)
            case '2':
                """
                    Takes two values from the user, one is a new x2 value, the other is a new y2 value, and changes
                    them in the circle
                """
                user_new_value_x2 = int(input('Enter a new value for x2: '))
                user_new_value_y2 = int(input('Enter a new value for y2: '))
                p2 = Point(user_new_value_x2, user_new_value_y2)
                user_line_name.p2 = p2
            case '3':
                """
                    Returns the start point and end point of the line
                """
                print(user_line_name.start_point)
                print(user_line_name.end_point)
            case'4':
                """
                    Prints the length of the line
                """
                print(user_line_name.length)
            case '0':
                break

