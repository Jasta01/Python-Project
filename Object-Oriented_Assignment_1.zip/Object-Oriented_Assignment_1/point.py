class Point:
    """""
        A class to represent a point on a grid with x and y coordinates
        
        attributes:
            X : float
                X coordinate in a grid
            Y: float
                Y coordinate in a grid
        
        @Properties:
            x
                :returns the x coordinate of a grid
            y
                :returns the y coordinate of a grid
                
        Methods:
            __eq__(self,other)
                :returns true if x and y in self are equal to x and y in other
    """""
    def __init__(self, x: float, y: float):
        """""
            Makes all necessary attributes for the point object
            
            parameters:
                x: float
                    x coordinate of the point
                y: float
                    y coordinate of the point
        """""
        self.__x = x
        self.__y = y

    @property
    def x(self):
        """
            :returns point x:
        """
        return self.__x

    @property
    def y(self):
        """
            :returns point y:
        """
        return self.__y

    def __str__(self):
        """"
            :returns point x and y
        """
        return f'({self.__x}, {self.__y})'

    def __eq__(self, other):
        return self.__x == other.x, self.__y == other.y


def choices():
    """""
        Prints the choices for the user to select from
    """""
    print('1. Create a point')
    print('2. Display the point')
    print('0. Exit')


if __name__ == "__main__":
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                """""
                    Allows the user to create a point, it takes 3 arguments, user_point_name, user_point_x, user_point_y
                """""
                user_point_name = input('Enter the name of the point: ')
                user_point_x = float(input('Enter point x: '))
                user_point_y = float(input('Enter point y: '))
                user_point_name = Point(user_point_x, user_point_y)
            case '2':
                """""
                    Displays the current circle using __str__
                """""
                print(user_point_name)
            case '0':
                break
            case _:
                print('Incorrect input, please try again...')
