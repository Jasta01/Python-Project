class Date:
    def __init__(self, day: int, month: int, year: int):
        self.__day = day
        self.__month = month
        self.__year = year

        if type(day) is not int:
            raise TypeError('Type day has to be an int.')
        if type(month) is not int:
            raise TypeError('Type month has to be an int.')
        if type(year) is not int:
            raise TypeError('Type year has to be an int.')

        if day > 31 or day < 1:
            raise ValueError('Day has to be between 1-31 days.')
        if month > 12 or month < 1:
            raise ValueError('Month has to be between 1 and 12 months.')

    @property
    def is_valid_date(self):
        if self.__month in ('April', 'June', 'September', 'November'):
            max_day = 30
            if self.__day > max_day or self.__day <= 0:
                print('Broken here')
                return False
            else:
                return True
        elif self.__month in ('January', 'March', 'May', 'July', 'August', 'October', 'December'):
            max_day = 31
            if self.__day > max_day or self.__day <= 0:
                print('Broken here')
                return False
            else:
                return True
        elif self.__month == 'February':
            max_day = 28
            if self.__day > max_day or self.__day <= 0:
                print('Broken here')
                return False
            else:
                return True

    @property
    def day(self):
        return self.__day

    @property
    def month(self):
        return self.__month

    @property
    def year(self):
        return self.__year

    @year.setter
    def year(self, new_value):
        self.__year = new_value

    @month.setter
    def month(self, new_value):
        self.__month = new_value

    @day.setter
    def day(self, new_value):
        self.__day = new_value
