import math


class Circle:
    """""
    A class to get a circles properties.
    
    Attributes:
        __radius: float
            Radius of the circle.
        __color: string
            Color of the circle, with a default of red.
    
    @properties:
        radius:
            Get the radius of the circle
        color:
            Get the color of the circle
    
    Methods:
        get_area(): 
            returns area of the circle.
        get_circumference(): 
            returns circumference of the circle.
        __str__: 
            returns the area of the circle in type string.
    """""

    def __init__(self, radius: float, color: str = 'red'):
        """""
        Constructs the necessary attributes for the class object.
        
        Parameters:
            radius: float
                Radius of the circle
            color: string
                Color of the circle
            
        """""
        assert type(radius) == float, "The radius has to be a float"
        assert radius > 0, "The radius has to be greater than 0"
        self.__radius = radius
        self.__color = color
        if type(color) != str:
            raise TypeError('Color has to be a string.')

    @property
    def radius(self):
        """""
        Returns the radius
        """""
        return self.__radius

    @radius.setter
    def radius(self, new_value: float):
        """""
        Parameters:
            self,
            new_value: float
            
        This function takes a input of new_value to change the radius of the circle
        """""
        if type(new_value) != float:
            raise TypeError('Radius has to be a float.')
        if new_value <= 0:
            raise ValueError('Radius has to be greater than 0.')
        self.__radius = new_value

    @property
    def color(self):
        """""
        Returns the color
        """""
        return self.__color

    @color.setter
    def color(self, new_value):
        """""
        Parameters:
            self,
            new_value: float

        This function takes a input of new_value to change the color of the circle
        """""
        if type(new_value) != str:
            raise TypeError('Color has to be a string.')
        self.__color = new_value

    def get_area(self):
        """""
        Gets area of circle
        """""
        return math.pi * self.__radius ** 2

    def get_circumference(self):
        """""
        Gets circumference of circle
        """""
        circ = math.pi * (self.__radius * 2)
        return circ

    def __str__(self):
        """""
        Returns a string with the radius in it.
        """""
        return f"The radius of the circle is: {self.__radius}"


def choices():
    """""
    Displays the users choices
    """""
    print('1. Create a new circle.')
    print('2. Edit radius.')
    print('3. Edit color')
    print('4. Display circle area.')
    print('5. Display circle circumference.')
    print('6. Display radius.')
    print('7. Display color.')
    print('0. Exit.')


if __name__ == "__main__":
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                """""
                Takes the users input to create a circle.
                """""
                circle_name = input('Enter the name of the circle: ')
                try:
                    circle_radius = float(input('Enter the radius of the circle: '))
                except ValueError as ve:
                    print(ve)
                try:
                    circle_color = input('Enter the color of the circle: ')
                except TypeError as te:
                    print(te)
                circle_name = Circle(circle_radius, circle_color)
            case '2':
                """""
                Takes a users input to edit the radius of the circle.
                """""
                try:
                    user_new_radius = float(input('Enter a new radius: '))
                except ValueError as ve:
                    print(ve)
                circle_name.radius = user_new_radius
            case '3':
                """""
                Takes a users input to edit the color of the circle.
                """""
                try:
                    user_new_color = input('Enter a new color: ')
                except TypeError as te:
                    print(te)
                circle_name.color = user_new_color
            case '4':
                print(circle_name.get_area())
            case '5':
                print(circle_name.get_circumference())
            case '6':
                print(circle_name)
            case '7':
                print(circle_name.color)
            case '0':
                break
            case _:
                print('Incorrect input, please try again.')
