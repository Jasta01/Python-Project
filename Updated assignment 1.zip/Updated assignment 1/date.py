class Date:
    """
            Date is a class which will determine if a date is a valid date, or if a date is a leap year.

            Attributes:
                day: int
                    A day in a date
                month: int
                    A month in a date
                year: int
                    A year in a date

            @properties:
                is_leap_year(self)
                    Determines if something is a leap year and returns True or False
                is_valid_date(self)
                    Determines if a date is a valid date and returns True or False
                day(self)
                    :returns the day
                month(self)
                    :returns the month
                year(self)
                    :returns the year
                day.setter(self, new_value)
                    sets the day to new_value
                month.setter(self, new_value)
                    sets the month to new_value
                year.setter(self, new_value)
                    sets the year to new_value


                Methods:
                    __str__(self):
                    :returns a string with the date, if it is a leap year and if it is a valid date

            """
    def __init__(self, day: int, month: int, year: int):
        """
        Constructs all the necessary attributes for the Date class, also asserts that the data within the date ire ints,
        And the days and months are valid days/months
        :param day:
            Day of a date
        :param month:
            Month of a date
        :param year:
            Year of a date
        """
        self.__day = day
        self.__month = month
        self.__year = year

        if type(day) is not int:
            raise TypeError('Type day has to be an int.')
        if type(month) is not int:
            raise TypeError('Type month has to be an int.')
        if type(year) is not int:
            raise TypeError('Type year has to be an int.')

        if day > 31 or day < 1:
            raise ValueError('Day has to be between 1-31 days.')
        if month > 12 or month < 1:
            raise ValueError('Month has to be between 1 and 12 months.')

    @property
    def is_leap_year(self):
        """
        :returns True or False based on if a year is a leap year
        """
        if self.__year % 4 == 0 and (self.__year % 100 != 0 or self.__year % 400 == 0):
            return True
        else:
            return False

    @property
    def is_valid_date(self):
        """
        :returns True or False based on if a date is a valid date
        """
        if self.__month in (4, 6, 9, 11):
            max_day = 30
            if self.__day > max_day or self.__day <= 0:
                return False
            else:
                return True
        elif self.__month in (1, 3, 5, 7, 8, 10, 12):
            max_day = 31
            if self.__day > max_day or self.__day <= 0:
                return False
            else:
                return True
        elif self.__month == 2:
            if self.is_leap_year:
                max_day = 29
                if self.__day > max_day or self.__day <= 0:
                    return False
                else:
                    return True
            else:
                max_day = 28
                if self.__day > max_day or self.__day <= 0:
                    return False
                else:
                    return True

    @property
    def day(self):
        """
        :returns The day of a date
        """
        return self.__day

    @property
    def month(self):
        """
        :returns The month of a date
        """
        return self.__month

    @property
    def year(self):
        """
        :returns The year of a date
        """
        return self.__year

    @year.setter
    def year(self, new_value):
        """
        Sets the year to a new value 'new_value' if one is given
        """
        self.__year = new_value

    @month.setter
    def month(self, new_value):
        """
        Sets the month to a new value 'new_value' if one is given
        """
        self.__month = new_value

    @day.setter
    def day(self, new_value):
        """
        Sets the day to a new value 'new_value' if one is given
        """
        self.__day = new_value

    def __str__(self):
        day = self.__day
        return f'Your date {day}/{self.__month}/{self.__year}. is leap year: {self.is_leap_year}. is valid ' \
               f'date {self.is_valid_date}'


def choices():
    print('1. Create a date')
    print('2. Edit the day')
    print('3. Edit the month')
    print('4. Edit the year')
    print('5. check if it is a leap year')
    print('6. Check if the date is valid')
    print('7. Display all the information')
    print('0. Exit')


if __name__ == '__main__':
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                try:
                    user_date_name = input('Enter the name for the date class: ')
                    user_day = int(input('Enter the day for the date class: '))
                    user_month = int(input('Enter the month for the date class: '))
                    user_year = int(input('Enter the year for the date class: '))
                    user_date_name = Date(user_day, user_month, user_year)
                except TypeError as te:
                    print(te)
                except ValueError as ve:
                    print(ve)
            case '2':
                user_new_day = int(input('Enter the new day: '))
                user_date_name.day = user_new_day
            case '3':
                user_new_month = int(input('Enter the new month: '))
                user_date_name.month = user_new_month
            case '4':
                user_new_year = int(input('Enter the new year: '))
                user_date_name.year = user_new_year
            case '5':
                print(user_date_name.is_leap_year)
            case '6':
                print(user_date_name.is_valid_date)
            case '7':
                print(user_date_name)

