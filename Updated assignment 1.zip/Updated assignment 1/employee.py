from datetime import date


class Employee:
    employee_counter = 0

    def __init__(self, first_name, last_name, salary: float, date_of_birth):
        Employee.employee_counter += 1
        self.__first_name = first_name
        self.__last_name = last_name
        self.__employee_id = 'E' + str(self.employee_counter).zfill(4)
        self.__salary = salary
        self.__date_of_birth = date_of_birth

    @property
    def employee_id(self):
        return self.__employee_id

    @property
    def annual_salary(self):
        return self.__salary * 12

    @property
    def salary(self):
        return self.__salary

    @property
    def name(self):
        return f'{self.__first_name} {self.__last_name}'

    @property
    def age(self):
        return int((date.today() - self.__date_of_birth).days / 365.2425)

    def raise_salary(self, raise_percent):
        self.__salary = self.salary + self.__salary * (raise_percent / 100)
        return self.__salary

    def __str__(self):
        return f'The customer, named {self.name} was born on {self.__date_of_birth} and is {self.age} year\'s old. ' \
               f'They have a monthly salary of {self.__salary} and a annual salary of {self.annual_salary} and their ' \
               f'employee ID is {self.employee_id}'


def choices():
    print('1. Create a new employee')
    print('2. get the employee\'s total information')
    print('3. give the employee a raise')
    print('0. exit')


if __name__ == '__main__':
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                employee_first_name = input('Enter the employee\'s first name: ')
                employee_last_name = input('Enter the employee\'s last name: ')
                employee_salary = float(input('Enter the salary for the employee: '))
                employee_dob_day = int(input('Enter the day the employee was born: '))
                employee_dob_month = int(input('Enter the month the employee was born: '))
                employee_dob_year = int(input('Enter the year the employee was born: '))
                date_of_birth = date(year=employee_dob_year, month=employee_dob_month, day=employee_dob_day)
                employee_first_name = Employee(employee_first_name, employee_last_name, employee_salary, date_of_birth)
            case '2':
                print(employee_first_name)
            case '3':
                pass
            case '0':
                break
