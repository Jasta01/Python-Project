from line import Line
from point import Point


class Rectangle:
    """
            A class that will return the area and perimeter of a rectangle given 2 points on a grid.

            attributes:
                Bottom_left_corner:
                    X and Y coordinate of the bottom left corner of a rectangle
                top_right_corner:
                    X and Y coordinate of the top right corner of a rectangle

            @Properties:
                bottom_right_corner:
                    :returns the x and y coordinate of the bottom right corner 
                    
                top_left_corner:
                    :returns the x and y coordinate of the top left corner
                    
                bottom_left_corner:
                    :returns the x and y coordinate of the bottom left corner
                    
                top_right_corner:
                    :returns the x and y coordinate of the top right corner
                    
                area:
                    :returns the area of the rectangle
                    
                perimeter:
                    :returns the perimeter of the rectangle
                    

            Methods:
                __str__(self, other)
                    :returns the area and perimiter of the rectangle
                
        """
    def __init__(self, bottom_left_corner, top_right_corner):
        """
            Constructs all the necessary attributes for the Rectangle class
            :param bottom_left_corner:
                The x and y coordinate of the bottom left corner of a rectangle
            :param top_right_corner:
                The x and y coordinate of the top right corner of a rectangle
        """
        self.__bottom_left_corner = bottom_left_corner
        self.__top_right_corner = top_right_corner
        if not isinstance(bottom_left_corner, Point):
            raise AssertionError('bottom_left_corner has to be an object of the Point Class')
        if not isinstance(top_right_corner, Point):
            raise AssertionError('top_right_corner has to be an object of the Point Class')

    @property
    def bottom_right_corner(self):
        """
        :returns the bottom right corner of a rectangle
        """
        return Point(self.__top_right_corner.x, self.__bottom_left_corner.y)

    @property
    def top_left_corner(self):
        """
        :returns the top left corner of a rectangle
        """
        return Point(self.__bottom_left_corner.x, self.__top_right_corner.y)

    @property
    def bottom_left_corner(self):
        """
        :returns the bottom left corner of a rectangle
        """
        return self.__bottom_left_corner

    @property
    def top_right_corner(self):
        """
        :returns the top right corner of a rectangle
        """
        return self.__top_right_corner

    @property
    def area(self):
        """
        :returns the area of a rectangle given 2 corners on a rectangle
        """
        l = Line(self.top_left_corner, self.bottom_left_corner).length
        w = Line(self.bottom_left_corner, self.bottom_right_corner).length
        return l * w

    @property
    def perimeter(self):
        """
        :returns the perimeter of a rectangle given 2 corners on a rectangle
        """
        l = Line(self.top_left_corner, self.bottom_left_corner).length
        w = Line(self.bottom_left_corner, self.bottom_right_corner).length
        return 2 * (l + w)

    def __str__(self):
        return f'The area of the rectangle is {Rectangle.area} and the perimeter is {Rectangle.perimeter}'


def choices():
    print('1. Create a rectangle')
    print('2. Display the area of the rectangle')
    print('3. Display the perimeter of the rectangle')
    print('0. Exit')


if __name__ == "__main__":
    while True:
        choices()
        user_input = input('Enter a choice: ')
        match user_input:
            case '1':
                rectangle_name = input('What is the name of the rectangle?: ')
                top_right_corner_x = float(input('X coordinate for the top right corner: '))
                top_right_corner_y = float(input('Y coordinate for the top right corner: '))
                bottom_left_corner_x = float(input('X coordinate for the bottom left corner: '))
                bottom_left_corner_y = float(input('Y coordinate for the bottom left corner: '))
                top_right_corner_user = Point(top_right_corner_x, top_right_corner_y)
                bottom_left_corner_user = Point(bottom_left_corner_x, bottom_left_corner_y)
                rectangle_name = Rectangle(top_right_corner_user, bottom_left_corner_user)
            case '2':
                print(rectangle_name.area)
            case '3':
                print(rectangle_name.perimeter)
            case '0':
                break
            case _:
                print('Incorrect input, please try again...')

